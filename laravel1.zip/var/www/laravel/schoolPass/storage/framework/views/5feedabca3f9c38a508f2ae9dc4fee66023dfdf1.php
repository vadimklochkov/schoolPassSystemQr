<?php $__env->startSection('content'); ?>
<div class="mr-5 ml-5">
    <div class="mr-5 ml-5">
            <div class="mr-5 ml-5">
            <?php if(auth()->user()->role == 'admin'): ?>
                <table class="table">
                    <thead class="">
                        <tr>
                        <th width="50" scope="col">#</th>
                        <th width="300" scope="col">Имя</th>
                        <th width="500" scope="col">Комент (для временных)</th>
                        <th width="300" scope="col">Дата начала</th>
                        <th width="300" scope="col">Дата окончания</th>
                        <th width="200" scope="col">Тип</th>
                        <th width="150" scope="col">Одобрить</th>
                        <th width="150" scope="col">Отклонить</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $pass; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $el): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <th scope="row"><?php echo e($el->id); ?></th>
                        <td><?php echo e($el->name); ?></td>
                        <td><?php echo e($el->comm); ?></td>
                        <td><?php echo e($el->date1); ?></td>
                        <td><?php echo e($el->date2); ?></td>
                        <td><?php echo e($el->type); ?></td>
                        <td><a href="/home/<?php echo e($el->id); ?>/accept" class="btn btn-success text-light">Одобрить</a></td>
                        <td><a href="/home/<?php echo e($el->id); ?>/deny" class="btn btn-danger text-light">Отклонить</a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php else: ?>
                <table class="table">
                    <thead class="">
                        <tr>
                        <th width="50" scope="col">#</th>
                        <th width="300" scope="col">Имя</th>
                        <th width="500" scope="col">Комент (для временных)</th>
                        <th width="200" scope="col">Тип</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $pass; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $el): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <th scope="row"><?php echo e($el->id); ?></th>
                        <td><?php echo e($el->name); ?></td>
                        <td><?php echo e($el->comm); ?></td>
                        <td><?php echo e($el->type); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/laravel/schoolPass/resources/views/home.blade.php ENDPATH**/ ?>