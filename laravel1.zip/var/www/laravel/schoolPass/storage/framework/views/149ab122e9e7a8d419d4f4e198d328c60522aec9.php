<?php $__env->startSection('content'); ?>
<style>
h1 {   
  animation: blink 400ms alternate infinite;
}

@keyframes  blink {
  from {
    opacity: 1;
  }
  to {
    opacity: 0;
  }
}
</style>
<meta http-equiv="refresh" content="0; URL='/regpass'" />
<div class="alert text-center ml-5 mr-5">
    <h1>Перенаправление...</h1>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/laravel/schoolPass/resources/views/auth/register.blade.php ENDPATH**/ ?>